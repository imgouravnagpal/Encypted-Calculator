﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace AsliWala
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int i = 0;
        int j = 0;
        string en = "importance";
        double FirstNumber;
        string Operation;
        private void nichekro(System.Windows.Forms.Button name,int increment)
        {
            name.Location = new Point(name.Location.X, name.Location.Y + increment);
        }
        private double equals()
        {
            double SecondNumber;
            double Result;

            SecondNumber = Convert.ToDouble(SolutionBx.Text);

            if (Operation == "+")
            {
                Result = (FirstNumber + SecondNumber);
                SolutionBx.Text = Convert.ToString(Result);
                FirstNumber = Result;
            }
            if (Operation == "-")
            {
                Result = (FirstNumber - SecondNumber);
                SolutionBx.Text = Convert.ToString(Result);
                FirstNumber = Result;
            }
            if (Operation == "*")
            {
                Result = (FirstNumber * SecondNumber);
                SolutionBx.Text = Convert.ToString(Result);
                FirstNumber = Result;
            }
            if (Operation == "/")
            {
                if (SecondNumber == 0)
                {
                    SolutionBx.Text = "Cannot divide by zero";

                }
                else
                {
                    Result = (FirstNumber / SecondNumber);
                    SolutionBx.Text = Convert.ToString(Result);
                    FirstNumber = Result;
                }
            }
            return SecondNumber;
        }
        private void button10_Click(object sender, EventArgs e)
        {
            if (SolutionBx.Text == "0")
            {
                SolutionBx.Text = "6";
            }
            else
            {
                SolutionBx.Text += "6";
            }
        }
        double firstnumber = 0;
        private void zero_Click(object sender, EventArgs e)
        {
            if(SolutionBx.Text == "0")
            {
                SolutionBx.Text = "0";
            }
            else
            {
                SolutionBx.Text += "0";
            }
        }

        private void one_Click(object sender, EventArgs e)
        {
            if (SolutionBx.Text == "0")
            {
                SolutionBx.Text = "1";
            }
            else
            {
                SolutionBx.Text += "1";
            }
        }

        private void two_Click(object sender, EventArgs e)
        {
            if (SolutionBx.Text == "0")
            {
                SolutionBx.Text = "2";
            }
            else
            {
                SolutionBx.Text += "2";
            }
        }

        private void three_Click(object sender, EventArgs e)
        {
            if (SolutionBx.Text == "0")
            {
                SolutionBx.Text = "3";
            }
            else
            {
                SolutionBx.Text += "3";
            }
        }

        private void four_Click(object sender, EventArgs e)
        {
            if (SolutionBx.Text == "0")
            {
                SolutionBx.Text = "4";
            }
            else
            {
                SolutionBx.Text += "4";
            }
        }

        private void five_Click(object sender, EventArgs e)
        {
            if (SolutionBx.Text == "0")
            {
                SolutionBx.Text = "5";
            }
            else
            {
                SolutionBx.Text += "5";
            }
        }

        private void seven_Click(object sender, EventArgs e)
        {
            if (SolutionBx.Text == "0")
            {
                SolutionBx.Text = "7";
            }
            else
            {
                SolutionBx.Text += "7";
            }
        }

        private void eight_Click(object sender, EventArgs e)
        {
            if (SolutionBx.Text == "0")
            {
                SolutionBx.Text = "8";
            }
            else
            {
                SolutionBx.Text += "8";
            }
        }

        private void nine_Click(object sender, EventArgs e)
        {
            if (SolutionBx.Text == "0")
            {
                SolutionBx.Text = "9";
            }
            else
            {
                SolutionBx.Text += "9";
            }
        }
       
        private void plus_Click(object sender, EventArgs e)
        {
            if(Operationbx.Text != "" && Operation != "=")
            {
                double second = equals();
                Operation = "+";
                Operationbx.Text = Convert.ToString(FirstNumber) + " + ";
                SolutionBx.Text = "0";
                textBox1.Text = "";
                return;
            }
            FirstNumber = Convert.ToDouble(SolutionBx.Text);
            Operationbx.Text = SolutionBx.Text + " + ";
            SolutionBx.Text = "0";
            Operation = "+";
            textBox1.Text = "";
        }

        private void minus_Click(object sender, EventArgs e)
        {
            if (Operationbx.Text != "" && Operation != "=")
            {
                double second = equals();
                Operation = "-";
                Operationbx.Text = Convert.ToString(FirstNumber) + " - ";
                SolutionBx.Text = "0";
                textBox1.Text = "";
                return;
            }
            FirstNumber = Convert.ToDouble(SolutionBx.Text);
            Operationbx.Text = SolutionBx.Text + " - ";
            SolutionBx.Text = "0";
            Operation = "-";
            textBox1.Text = "";
        }

        private void multiply_Click(object sender, EventArgs e)
        {
            if (Operationbx.Text != "" && Operation != "=")
            {
                double second = equals();
                Operation = "*";
                Operationbx.Text = Convert.ToString(FirstNumber) + " x ";
                SolutionBx.Text = "0";
                textBox1.Text = "";
                return;
            }
            FirstNumber = Convert.ToDouble(SolutionBx.Text);
            Operationbx.Text = SolutionBx.Text + " x ";
            SolutionBx.Text = "0";
            Operation = "*";
            textBox1.Text = "";
        }

        private void devide_Click(object sender, EventArgs e)
        {
            if (Operationbx.Text != "" && Operation != "=")
            {

                
                double second = equals();
                Operation = "/";
                Operationbx.Text = Convert.ToString(FirstNumber) + " / ";
                SolutionBx.Text = "0";
                textBox1.Text = "";
                return;
            }
            FirstNumber = Convert.ToDouble(SolutionBx.Text);
            Operationbx.Text = SolutionBx.Text + " / ";
            SolutionBx.Text = "0";
            Operation = "/";
            textBox1.Text = "";
        }

        private void Operationbx_TextChanged(object sender, EventArgs e)
        {

        }

        private void equalto_Click(object sender, EventArgs e)
        {
            double SecondNumber = equals();
            Operationbx.Text += Convert.ToString(SecondNumber) + " = ";
            Operation = "=";
        }

        private void dot_Click(object sender, EventArgs e)
        {
            SolutionBx.Text = SolutionBx.Text + ".";
        }

        private void clear_Click(object sender, EventArgs e)
        {
            Operationbx.Text = "";
            SolutionBx.Text = "0";
            textBox1.Text = "";
            FirstNumber = 0;
        }

        private void onedevx_Click(object sender, EventArgs e)
        {
            FirstNumber = Convert.ToDouble(SolutionBx.Text);
            SolutionBx.Text = Convert.ToString(1.0 / FirstNumber);
            Operationbx.Text = "1 / " + Convert.ToString(FirstNumber) + " = ";
            FirstNumber = (1.0 / FirstNumber);
        }

        private void xsquare_Click(object sender, EventArgs e)
        {
            FirstNumber = Convert.ToDouble(SolutionBx.Text);
            SolutionBx.Text = Convert.ToString(FirstNumber*FirstNumber);
            Operationbx.Text = Convert.ToString(FirstNumber) +"² = ";
            FirstNumber = (FirstNumber*FirstNumber);
        }

        private void backspace_Click(object sender, EventArgs e)
        {
            if(SolutionBx.Text.Length != 0)
            SolutionBx.Text = SolutionBx.Text.Remove(SolutionBx.Text.Length - 1, 1);
            
            
        }

        private void twodevx_Click(object sender, EventArgs e)
        {
            FirstNumber = Convert.ToDouble(SolutionBx.Text);
            SolutionBx.Text = Convert.ToString(Math.Sqrt(FirstNumber));
            Operationbx.Text = "2√" + Convert.ToString(FirstNumber) + " = ";
            FirstNumber = (Math.Sqrt(FirstNumber));
        }

        private void plusminus_Click(object sender, EventArgs e)
        {
            if (SolutionBx.Text[0] == '-')
            {
                SolutionBx.Text = SolutionBx.Text.Substring(1);
            }
            else
            {
                SolutionBx.Text = "-" + SolutionBx.Text;
            }
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
            timer5.Enabled = true;
            
        }

        private void clearentry_Click(object sender, EventArgs e)
        {

            if (clearentry.BackColor == Color.Green)
            {
                clearentry.BackColor = DefaultBackColor;
                textBox1.Visible = false;
                
                comboBox1.Visible = false;
                Form1.ActiveForm.Height = 408;
                j = 0;
                timer3.Enabled = true;
            }
            else
            {
                clearentry.BackColor = Color.Green;
                textBox1.Visible = true;
                
                comboBox1.Visible = true;
                j = 0;
                i = 0;
                timer1.Enabled = true;
                timer2.Enabled = true;
            }
            


        }

        private void SolutionBx_TextChanged(object sender, EventArgs e)
        {
            if(clearentry.BackColor != Color.Green)
            {
                return;
            }
            if(SolutionBx.Text == "")
            {
                textBox1.Text = "";
                return;
            }
            
                textBox1.Text = "";
               
               for(int i=0;i<SolutionBx.Text.Length;i++)
                {
                    textBox1.Text += en[SolutionBx.Text[i]-'0'];
                }
            
            

            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            i++;
            Form1.ActiveForm.Height += i;
            if(Form1.ActiveForm.Height >=499)
            {
                timer1.Enabled = false;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void mod_Click(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            j++;
            nichekro(plusminus, j);
            nichekro(zero, j);
            nichekro(dot, j);
            nichekro(equalto, j);
            nichekro(one, j);
            nichekro(two, j);
            nichekro(three, j);
            nichekro(four, j);
            nichekro(five, j);
            nichekro(six,j);
            nichekro(seven, j);
            nichekro(eight, j);
            nichekro(nine, j);
            nichekro(plus, j);
            nichekro(minus, j);
            nichekro(multiply, j);
            nichekro(devide, j);
            nichekro(xsquare, j);
            nichekro(twodevx, j);
            nichekro(onedevx, j);
            nichekro(mod, j);
            nichekro(clear, j);
            nichekro(clearentry, j);
            nichekro(backspace, j);
            textBox1.Location = new Point(textBox1.Location.X,textBox1.Location.Y+j);
            if(plusminus.Location.Y >= 374)
            {
                timer2.Enabled = false;
            }

        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            j--;
            textBox1.Location = new Point(textBox1.Location.X, textBox1.Location.Y + j);
            nichekro(plusminus, j);
            nichekro(zero, j);
            nichekro(dot, j);
            nichekro(equalto, j);
            nichekro(one, j);
            nichekro(two, j);
            nichekro(three, j);
            nichekro(four, j);
            nichekro(five, j);
            nichekro(six, j);
            nichekro(seven, j);
            nichekro(eight, j);
            nichekro(nine, j);
            nichekro(plus, j);
            nichekro(minus, j);
            nichekro(multiply, j);
            nichekro(devide, j);
            nichekro(xsquare, j);
            nichekro(twodevx, j);
            nichekro(onedevx, j);
            nichekro(mod, j);
            nichekro(clear, j);
            nichekro(clearentry, j);
            nichekro(backspace, j);
            if (plusminus.Location.Y <= 319)
            {
                timer3.Enabled = false;
            }
        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            i--;
            Form1.ActiveForm.Height += i;
            if (Form1.ActiveForm.Height <= 408)
            {
                timer4.Enabled = false;
            }
        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            Form1.ActiveForm.Size = new Size(308, 408);
            timer5.Enabled = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox1.Text == "acegikmoqs")
                en = comboBox1.Text;
        }

        private void nine_Click_1(object sender, EventArgs e)
        {
            if (SolutionBx.Text == "0")
            {
                SolutionBx.Text = "9";
            }
            else
            {
                SolutionBx.Text += "9";
            }
        }
    }
}

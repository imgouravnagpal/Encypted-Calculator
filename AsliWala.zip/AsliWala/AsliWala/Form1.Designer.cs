﻿namespace AsliWala
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.plusminus = new System.Windows.Forms.Button();
            this.zero = new System.Windows.Forms.Button();
            this.dot = new System.Windows.Forms.Button();
            this.equalto = new System.Windows.Forms.Button();
            this.plus = new System.Windows.Forms.Button();
            this.three = new System.Windows.Forms.Button();
            this.two = new System.Windows.Forms.Button();
            this.one = new System.Windows.Forms.Button();
            this.minus = new System.Windows.Forms.Button();
            this.six = new System.Windows.Forms.Button();
            this.five = new System.Windows.Forms.Button();
            this.four = new System.Windows.Forms.Button();
            this.multiply = new System.Windows.Forms.Button();
            this.nine = new System.Windows.Forms.Button();
            this.eight = new System.Windows.Forms.Button();
            this.seven = new System.Windows.Forms.Button();
            this.devide = new System.Windows.Forms.Button();
            this.twodevx = new System.Windows.Forms.Button();
            this.xsquare = new System.Windows.Forms.Button();
            this.onedevx = new System.Windows.Forms.Button();
            this.backspace = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.clearentry = new System.Windows.Forms.Button();
            this.mod = new System.Windows.Forms.Button();
            this.SolutionBx = new System.Windows.Forms.TextBox();
            this.Operationbx = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.timer5 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // plusminus
            // 
            this.plusminus.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.plusminus.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plusminus.Location = new System.Drawing.Point(2, 319);
            this.plusminus.Name = "plusminus";
            this.plusminus.Size = new System.Drawing.Size(75, 50);
            this.plusminus.TabIndex = 0;
            this.plusminus.Text = "+/-";
            this.plusminus.UseVisualStyleBackColor = false;
            this.plusminus.Click += new System.EventHandler(this.plusminus_Click);
            // 
            // zero
            // 
            this.zero.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.zero.Cursor = System.Windows.Forms.Cursors.Hand;
            this.zero.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zero.Location = new System.Drawing.Point(74, 319);
            this.zero.Name = "zero";
            this.zero.Size = new System.Drawing.Size(75, 50);
            this.zero.TabIndex = 1;
            this.zero.Text = "0";
            this.zero.UseVisualStyleBackColor = false;
            this.zero.Click += new System.EventHandler(this.zero_Click);
            // 
            // dot
            // 
            this.dot.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.dot.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dot.Location = new System.Drawing.Point(144, 319);
            this.dot.Name = "dot";
            this.dot.Size = new System.Drawing.Size(75, 50);
            this.dot.TabIndex = 2;
            this.dot.Text = ".";
            this.dot.UseVisualStyleBackColor = false;
            this.dot.Click += new System.EventHandler(this.dot_Click);
            // 
            // equalto
            // 
            this.equalto.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.equalto.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.equalto.Location = new System.Drawing.Point(216, 319);
            this.equalto.Name = "equalto";
            this.equalto.Size = new System.Drawing.Size(75, 50);
            this.equalto.TabIndex = 3;
            this.equalto.Text = "=";
            this.equalto.UseVisualStyleBackColor = false;
            this.equalto.Click += new System.EventHandler(this.equalto_Click);
            // 
            // plus
            // 
            this.plus.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plus.Location = new System.Drawing.Point(216, 271);
            this.plus.Name = "plus";
            this.plus.Size = new System.Drawing.Size(75, 50);
            this.plus.TabIndex = 7;
            this.plus.Text = "+";
            this.plus.UseVisualStyleBackColor = true;
            this.plus.Click += new System.EventHandler(this.plus_Click);
            // 
            // three
            // 
            this.three.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.three.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.three.Location = new System.Drawing.Point(144, 271);
            this.three.Name = "three";
            this.three.Size = new System.Drawing.Size(75, 50);
            this.three.TabIndex = 6;
            this.three.Text = "3";
            this.three.UseVisualStyleBackColor = false;
            this.three.Click += new System.EventHandler(this.three_Click);
            // 
            // two
            // 
            this.two.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.two.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.two.Location = new System.Drawing.Point(74, 271);
            this.two.Name = "two";
            this.two.Size = new System.Drawing.Size(75, 50);
            this.two.TabIndex = 5;
            this.two.Text = "2";
            this.two.UseVisualStyleBackColor = false;
            this.two.Click += new System.EventHandler(this.two_Click);
            // 
            // one
            // 
            this.one.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.one.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.one.Location = new System.Drawing.Point(2, 271);
            this.one.Name = "one";
            this.one.Size = new System.Drawing.Size(75, 50);
            this.one.TabIndex = 4;
            this.one.Text = "1";
            this.one.UseVisualStyleBackColor = false;
            this.one.Click += new System.EventHandler(this.one_Click);
            // 
            // minus
            // 
            this.minus.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minus.Location = new System.Drawing.Point(216, 226);
            this.minus.Name = "minus";
            this.minus.Size = new System.Drawing.Size(75, 50);
            this.minus.TabIndex = 11;
            this.minus.Text = "-";
            this.minus.UseVisualStyleBackColor = true;
            this.minus.Click += new System.EventHandler(this.minus_Click);
            // 
            // six
            // 
            this.six.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.six.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.six.Location = new System.Drawing.Point(144, 226);
            this.six.Name = "six";
            this.six.Size = new System.Drawing.Size(75, 50);
            this.six.TabIndex = 10;
            this.six.Text = "6";
            this.six.UseVisualStyleBackColor = false;
            this.six.Click += new System.EventHandler(this.button10_Click);
            // 
            // five
            // 
            this.five.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.five.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.five.Location = new System.Drawing.Point(74, 226);
            this.five.Name = "five";
            this.five.Size = new System.Drawing.Size(75, 50);
            this.five.TabIndex = 9;
            this.five.Text = "5";
            this.five.UseVisualStyleBackColor = false;
            this.five.Click += new System.EventHandler(this.five_Click);
            // 
            // four
            // 
            this.four.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.four.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.four.Location = new System.Drawing.Point(2, 226);
            this.four.Name = "four";
            this.four.Size = new System.Drawing.Size(75, 50);
            this.four.TabIndex = 8;
            this.four.Text = "4";
            this.four.UseVisualStyleBackColor = false;
            this.four.Click += new System.EventHandler(this.four_Click);
            // 
            // multiply
            // 
            this.multiply.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.multiply.Location = new System.Drawing.Point(216, 181);
            this.multiply.Name = "multiply";
            this.multiply.Size = new System.Drawing.Size(75, 50);
            this.multiply.TabIndex = 15;
            this.multiply.Text = "x";
            this.multiply.UseVisualStyleBackColor = true;
            this.multiply.Click += new System.EventHandler(this.multiply_Click);
            // 
            // nine
            // 
            this.nine.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.nine.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nine.Location = new System.Drawing.Point(144, 181);
            this.nine.Name = "nine";
            this.nine.Size = new System.Drawing.Size(75, 50);
            this.nine.TabIndex = 14;
            this.nine.Text = "9";
            this.nine.UseVisualStyleBackColor = false;
            this.nine.Click += new System.EventHandler(this.nine_Click_1);
            // 
            // eight
            // 
            this.eight.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.eight.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eight.Location = new System.Drawing.Point(74, 181);
            this.eight.Name = "eight";
            this.eight.Size = new System.Drawing.Size(75, 50);
            this.eight.TabIndex = 13;
            this.eight.Text = "8";
            this.eight.UseVisualStyleBackColor = false;
            this.eight.Click += new System.EventHandler(this.eight_Click);
            // 
            // seven
            // 
            this.seven.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.seven.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seven.Location = new System.Drawing.Point(2, 181);
            this.seven.Name = "seven";
            this.seven.Size = new System.Drawing.Size(75, 50);
            this.seven.TabIndex = 12;
            this.seven.Text = "7";
            this.seven.UseVisualStyleBackColor = false;
            this.seven.Click += new System.EventHandler(this.seven_Click);
            // 
            // devide
            // 
            this.devide.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.devide.Location = new System.Drawing.Point(216, 135);
            this.devide.Name = "devide";
            this.devide.Size = new System.Drawing.Size(75, 50);
            this.devide.TabIndex = 19;
            this.devide.Text = "/";
            this.devide.UseVisualStyleBackColor = true;
            this.devide.Click += new System.EventHandler(this.devide_Click);
            // 
            // twodevx
            // 
            this.twodevx.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.twodevx.Location = new System.Drawing.Point(144, 135);
            this.twodevx.Name = "twodevx";
            this.twodevx.Size = new System.Drawing.Size(75, 50);
            this.twodevx.TabIndex = 18;
            this.twodevx.Text = "2√x";
            this.twodevx.UseVisualStyleBackColor = true;
            this.twodevx.Click += new System.EventHandler(this.twodevx_Click);
            // 
            // xsquare
            // 
            this.xsquare.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xsquare.Location = new System.Drawing.Point(74, 135);
            this.xsquare.Name = "xsquare";
            this.xsquare.Size = new System.Drawing.Size(75, 50);
            this.xsquare.TabIndex = 17;
            this.xsquare.Text = "x²";
            this.xsquare.UseVisualStyleBackColor = true;
            this.xsquare.Click += new System.EventHandler(this.xsquare_Click);
            // 
            // onedevx
            // 
            this.onedevx.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.onedevx.Location = new System.Drawing.Point(2, 135);
            this.onedevx.Name = "onedevx";
            this.onedevx.Size = new System.Drawing.Size(75, 50);
            this.onedevx.TabIndex = 16;
            this.onedevx.Text = "1/x";
            this.onedevx.UseVisualStyleBackColor = true;
            this.onedevx.Click += new System.EventHandler(this.onedevx_Click);
            // 
            // backspace
            // 
            this.backspace.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backspace.Location = new System.Drawing.Point(216, 88);
            this.backspace.Name = "backspace";
            this.backspace.Size = new System.Drawing.Size(75, 50);
            this.backspace.TabIndex = 23;
            this.backspace.Text = "<--";
            this.backspace.UseVisualStyleBackColor = true;
            this.backspace.Click += new System.EventHandler(this.backspace_Click);
            // 
            // clear
            // 
            this.clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clear.Location = new System.Drawing.Point(144, 88);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(75, 50);
            this.clear.TabIndex = 22;
            this.clear.Text = "C";
            this.clear.UseVisualStyleBackColor = true;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // clearentry
            // 
            this.clearentry.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearentry.Location = new System.Drawing.Point(74, 88);
            this.clearentry.Name = "clearentry";
            this.clearentry.Size = new System.Drawing.Size(75, 50);
            this.clearentry.TabIndex = 21;
            this.clearentry.Text = "EN";
            this.clearentry.UseVisualStyleBackColor = true;
            this.clearentry.Click += new System.EventHandler(this.clearentry_Click);
            // 
            // mod
            // 
            this.mod.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mod.Location = new System.Drawing.Point(2, 88);
            this.mod.Name = "mod";
            this.mod.Size = new System.Drawing.Size(75, 50);
            this.mod.TabIndex = 20;
            this.mod.Text = "%";
            this.mod.UseVisualStyleBackColor = true;
            this.mod.Click += new System.EventHandler(this.mod_Click);
            // 
            // SolutionBx
            // 
            this.SolutionBx.BackColor = System.Drawing.SystemColors.Control;
            this.SolutionBx.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SolutionBx.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SolutionBx.Location = new System.Drawing.Point(4, 27);
            this.SolutionBx.Name = "SolutionBx";
            this.SolutionBx.Size = new System.Drawing.Size(288, 55);
            this.SolutionBx.TabIndex = 24;
            this.SolutionBx.Text = "0";
            this.SolutionBx.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.SolutionBx.TextChanged += new System.EventHandler(this.SolutionBx_TextChanged);
            // 
            // Operationbx
            // 
            this.Operationbx.BackColor = System.Drawing.SystemColors.Control;
            this.Operationbx.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Operationbx.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Operationbx.Location = new System.Drawing.Point(4, 1);
            this.Operationbx.Name = "Operationbx";
            this.Operationbx.Size = new System.Drawing.Size(289, 25);
            this.Operationbx.TabIndex = 25;
            this.Operationbx.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Operationbx.TextChanged += new System.EventHandler(this.Operationbx_TextChanged);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.Control;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(2, 32);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(288, 55);
            this.textBox1.TabIndex = 26;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBox1.Visible = false;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // timer1
            // 
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 10;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.SystemColors.Control;
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "acegikmoqs",
            "importance"});
            this.comboBox1.Location = new System.Drawing.Point(145, 433);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(146, 24);
            this.comboBox1.TabIndex = 27;
            this.comboBox1.Text = "Select";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // timer4
            // 
            this.timer4.Tick += new System.EventHandler(this.timer4_Tick);
            // 
            // timer5
            // 
            this.timer5.Tick += new System.EventHandler(this.timer5_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(478, 448);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Operationbx);
            this.Controls.Add(this.SolutionBx);
            this.Controls.Add(this.backspace);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.clearentry);
            this.Controls.Add(this.mod);
            this.Controls.Add(this.devide);
            this.Controls.Add(this.twodevx);
            this.Controls.Add(this.xsquare);
            this.Controls.Add(this.onedevx);
            this.Controls.Add(this.multiply);
            this.Controls.Add(this.nine);
            this.Controls.Add(this.eight);
            this.Controls.Add(this.seven);
            this.Controls.Add(this.minus);
            this.Controls.Add(this.six);
            this.Controls.Add(this.five);
            this.Controls.Add(this.four);
            this.Controls.Add(this.plus);
            this.Controls.Add(this.three);
            this.Controls.Add(this.two);
            this.Controls.Add(this.one);
            this.Controls.Add(this.equalto);
            this.Controls.Add(this.dot);
            this.Controls.Add(this.zero);
            this.Controls.Add(this.plusminus);
            this.Name = "Form1";
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Shown += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button plusminus;
        private System.Windows.Forms.Button zero;
        private System.Windows.Forms.Button dot;
        private System.Windows.Forms.Button equalto;
        private System.Windows.Forms.Button plus;
        private System.Windows.Forms.Button three;
        private System.Windows.Forms.Button two;
        private System.Windows.Forms.Button one;
        private System.Windows.Forms.Button minus;
        private System.Windows.Forms.Button six;
        private System.Windows.Forms.Button five;
        private System.Windows.Forms.Button four;
        private System.Windows.Forms.Button multiply;
        private System.Windows.Forms.Button nine;
        private System.Windows.Forms.Button eight;
        private System.Windows.Forms.Button seven;
        private System.Windows.Forms.Button devide;
        private System.Windows.Forms.Button twodevx;
        private System.Windows.Forms.Button xsquare;
        private System.Windows.Forms.Button onedevx;
        private System.Windows.Forms.Button backspace;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.Button clearentry;
        private System.Windows.Forms.Button mod;
        private System.Windows.Forms.TextBox SolutionBx;
        private System.Windows.Forms.TextBox Operationbx;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.Timer timer5;
    }
}

